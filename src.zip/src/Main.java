import account.Account;

/**
 * Login -> Login 성공 시 main 실행 -> routines 기능 사용 -> 종료 시 json 파일로 저장 -> 종료
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("== 루틴 UI ==");
        System.out.println("1. 루틴 추가");
        System.out.println("2. 루틴 삭제");
        System.out.println("3. 루틴 수정 (이건 뭐 어떻게?)");
    }
}
